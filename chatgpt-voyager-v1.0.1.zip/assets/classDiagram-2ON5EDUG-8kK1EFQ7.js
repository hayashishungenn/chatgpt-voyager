import { s as styles_default, c as classRenderer_v3_unified_default, a as classDiagram_default, C as ClassDB } from "./chunk-B4BG7PRW-BlyyNMbf.js";
import { _ as __name } from "./mermaid.core-D2dGn9Jp.js";
import "./chunk-FMBD7UC4-CGNU4Fqq.js";
import "./chunk-55IACEB6-dEQtfLSd.js";
import "./chunk-QN33PNHL-Dzws9JLi.js";
import "./index.ts-DXm6kdPJ.js";
import "./storage-G_NSCLrW.js";
var diagram = {
  parser: classDiagram_default,
  get db() {
    return new ClassDB();
  },
  renderer: classRenderer_v3_unified_default,
  styles: styles_default,
  init: /* @__PURE__ */ __name((cnf) => {
    if (!cnf.class) {
      cnf.class = {};
    }
    cnf.class.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
  }, "init")
};
export {
  diagram
};
