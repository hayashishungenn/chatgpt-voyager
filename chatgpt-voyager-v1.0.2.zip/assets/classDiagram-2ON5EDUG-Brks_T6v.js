import { s as styles_default, c as classRenderer_v3_unified_default, a as classDiagram_default, C as ClassDB } from "./chunk-B4BG7PRW-CnPTIYdC.js";
import { _ as __name } from "./mermaid.core-Cs19wwQR.js";
import "./chunk-FMBD7UC4-D6brstu4.js";
import "./chunk-55IACEB6-CiSf7P_A.js";
import "./chunk-QN33PNHL-C9PS5x6p.js";
import "./index.ts-DKQ8VMuU.js";
import "./storage-G_NSCLrW.js";
var diagram = {
  parser: classDiagram_default,
  get db() {
    return new ClassDB();
  },
  renderer: classRenderer_v3_unified_default,
  styles: styles_default,
  init: /* @__PURE__ */ __name((cnf) => {
    if (!cnf.class) {
      cnf.class = {};
    }
    cnf.class.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
  }, "init")
};
export {
  diagram
};
