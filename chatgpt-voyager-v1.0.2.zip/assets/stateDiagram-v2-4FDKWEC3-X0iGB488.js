import { s as styles_default, b as stateRenderer_v3_unified_default, a as stateDiagram_default, S as StateDB } from "./chunk-DI55MBZ5-Dey6hoVz.js";
import { _ as __name } from "./mermaid.core-Cs19wwQR.js";
import "./chunk-55IACEB6-CiSf7P_A.js";
import "./chunk-QN33PNHL-C9PS5x6p.js";
import "./index.ts-DKQ8VMuU.js";
import "./storage-G_NSCLrW.js";
var diagram = {
  parser: stateDiagram_default,
  get db() {
    return new StateDB(2);
  },
  renderer: stateRenderer_v3_unified_default,
  styles: styles_default,
  init: /* @__PURE__ */ __name((cnf) => {
    if (!cnf.state) {
      cnf.state = {};
    }
    cnf.state.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
  }, "init")
};
export {
  diagram
};
